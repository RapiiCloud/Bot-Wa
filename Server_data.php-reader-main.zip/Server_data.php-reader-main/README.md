# Server_data.php-reader
Growtopia server_data.php reader with bypass method, using discord bot

# How to use
```python
1 > install python
2 > change your bot token on line 12 (TOKEN = "YOUR_BOT_TOKEN")
3 > run python bot.py
```
